import os
import sys
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from werkzeug.utils import secure_filename
import pytesseract
from PIL import Image
import pdf2image
import re

# Configurações para processamento de documentos
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'tiff', 'bmp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_image(image_path):
    """Extrai texto de uma imagem usando OCR."""
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang='por')
        return text
    except Exception as e:
        print(f"Erro ao processar imagem: {e}")
        return ""

def extract_text_from_pdf(pdf_path):
    """Converte PDF para imagens e extrai texto usando OCR."""
    try:
        # Converter PDF para imagens
        images = pdf2image.convert_from_path(pdf_path)
        
        # Extrair texto de cada página
        text = ""
        for img in images:
            text += pytesseract.image_to_string(img, lang='por')
            text += "\n\n"
        
        return text
    except Exception as e:
        print(f"Erro ao processar PDF: {e}")
        return ""

def process_document(file_path):
    """Processa um documento (PDF ou imagem) e extrai informações relevantes."""
    # Determinar o tipo de arquivo
    file_extension = file_path.rsplit('.', 1)[1].lower()
    
    # Extrair texto do documento
    if file_extension == 'pdf':
        text = extract_text_from_pdf(file_path)
    else:  # Imagem
        text = extract_text_from_image(file_path)
    
    # Extrair informações relevantes usando expressões regulares
    ordem_servico = {}
    
    # Número da OS
    os_match = re.search(r'ORDEM\s+DE\s+SERVIÇO\s*[:#]?\s*(\d+)', text, re.IGNORECASE)
    if os_match:
        ordem_servico['numero'] = os_match.group(1)
    
    # Data
    data_match = re.search(r'(\d{2}/\d{2}/\d{4})', text)
    if data_match:
        ordem_servico['data'] = data_match.group(1)
    
    # Cliente
    cliente_match = re.search(r'Cliente\s*:\s*([^\n]+)', text, re.IGNORECASE)
    if cliente_match:
        ordem_servico['cliente'] = cliente_match.group(1).strip()
    
    # Veículo e placa
    veiculo_match = re.search(r'([A-Z]{3}-\d{4})\s*-\s*([^\n-]+)', text)
    if veiculo_match:
        ordem_servico['placa'] = veiculo_match.group(1).strip()
        ordem_servico['veiculo'] = veiculo_match.group(2).strip()
    
    # Quilometragem
    km_match = re.search(r'(quilometragem|km)\s*[:\s]\s*(\d+[\.,]?\d*)', text, re.IGNORECASE)
    if km_match:
        ordem_servico['quilometragem'] = km_match.group(2).replace(',', '.')
    
    # Problema informado
    problema_match = re.search(r'Problema\s+Informado\s*:\s*([^\n]+)', text, re.IGNORECASE)
    if problema_match:
        ordem_servico['problema'] = problema_match.group(1).strip()
    
    # Serviço executado
    servico_match = re.search(r'Serviço\s+Executado\s*:\s*([^\n]+)', text, re.IGNORECASE)
    if servico_match:
        ordem_servico['servico'] = servico_match.group(1).strip()
    
    # Itens de serviço (tentativa de extrair tabela)
    itens = []
    linhas = text.split('\n')
    for linha in linhas:
        # Procurar padrões que pareçam itens de serviço
        item_match = re.search(r'(\d+)\s+(\w+)\s+([^\d]+)\s+(\d+)\s+', linha)
        if item_match:
            item = {
                'codigo': item_match.group(1),
                'local': item_match.group(2),
                'descricao': item_match.group(3).strip(),
                'quantidade': item_match.group(4)
            }
            itens.append(item)
    
    if itens:
        ordem_servico['itens'] = itens
    
    # Funcionário
    funcionario_match = re.search(r'Funcionário\s*:\s*([^\n]+)', text, re.IGNORECASE)
    if funcionario_match:
        ordem_servico['funcionario'] = funcionario_match.group(1).strip()
    
    # Observações
    obs_match = re.search(r'Observações\s*:\s*([^\n]+(?:\n[^\n]+)*)', text, re.IGNORECASE)
    if obs_match:
        ordem_servico['observacoes'] = obs_match.group(1).strip()
    
    return {
        'texto_extraido': text,
        'ordem_servico': ordem_servico
    }
