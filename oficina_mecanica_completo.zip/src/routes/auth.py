from flask import Blueprint, request, jsonify, session, current_app
from werkzeug.security import generate_password_hash
from src.models.user import db, User
import functools

auth_bp = Blueprint('auth', __name__)

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Autenticação necessária'}), 401
        return view(*args, **kwargs)
    return wrapped_view

def admin_required(view):
    @functools.wraps(view)
    def wrapped_view(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Autenticação necessária'}), 401
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin():
            return jsonify({'error': 'Permissão negada. Acesso restrito a administradores'}), 403
        
        return view(*args, **kwargs)
    return wrapped_view

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Usuário e senha são obrigatórios'}), 400
    
    user = User.query.filter_by(username=data['username']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'error': 'Usuário ou senha inválidos'}), 401
    
    if not user.active:
        return jsonify({'error': 'Conta desativada. Entre em contato com o administrador'}), 403
    
    session['user_id'] = user.id
    session['user_role'] = user.role
    
    return jsonify({
        'message': 'Login realizado com sucesso',
        'user': {
            'id': user.id,
            'username': user.username,
            'role': user.role
        }
    })

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    session.pop('user_role', None)
    return jsonify({'message': 'Logout realizado com sucesso'})

@auth_bp.route('/users', methods=['GET'])
@admin_required
def get_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@auth_bp.route('/users', methods=['POST'])
@admin_required
def create_user():
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Todos os campos são obrigatórios'}), 400
    
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Nome de usuário já existe'}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email já está em uso'}), 400
    
    role = data.get('role', 'funcionario')
    if role not in ['funcionario', 'admin']:
        return jsonify({'error': 'Função inválida. Use "funcionario" ou "admin"'}), 400
    
    user = User(
        username=data['username'],
        email=data['email'],
        password=data['password'],
        role=role
    )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Usuário criado com sucesso',
        'user': user.to_dict()
    }), 201

@auth_bp.route('/users/<int:user_id>', methods=['PUT'])
@admin_required
def update_user(user_id):
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    data = request.get_json()
    
    if data.get('username') and data['username'] != user.username:
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Nome de usuário já existe'}), 400
        user.username = data['username']
    
    if data.get('email') and data['email'] != user.email:
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email já está em uso'}), 400
        user.email = data['email']
    
    if data.get('password'):
        user.password_hash = generate_password_hash(data['password'])
    
    if data.get('role') and data['role'] in ['funcionario', 'admin']:
        user.role = data['role']
    
    if 'active' in data:
        user.active = bool(data['active'])
    
    db.session.commit()
    
    return jsonify({
        'message': 'Usuário atualizado com sucesso',
        'user': user.to_dict()
    })

@auth_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    # Não permitir excluir o próprio usuário
    if session.get('user_id') == user_id:
        return jsonify({'error': 'Não é possível excluir o próprio usuário'}), 400
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': f'Usuário {user_id} excluído com sucesso'}), 200

@auth_bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    user = User.query.get(session['user_id'])
    return jsonify(user.to_dict())

@auth_bp.route('/check-auth', methods=['GET'])
def check_auth():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            return jsonify({
                'authenticated': True,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'role': user.role
                }
            })
    
    return jsonify({'authenticated': False})
