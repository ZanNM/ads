import os
import sys
from flask import Blueprint, request, jsonify
import requests
import re
import json
import base64
import cv2
import numpy as np
import pytesseract
from PIL import Image
import io

# Blueprint para API de consulta FIPE
fipe_api_bp = Blueprint('fipe_api', __name__)

# Configurações para OCR de placas
def configure_tesseract():
    """Configura o Tesseract OCR para reconhecimento de placas"""
    # Configurações específicas para reconhecimento de placas
    custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-'
    return custom_config

def preprocess_image_for_plate_recognition(image):
    """Pré-processa a imagem para melhorar o reconhecimento de placas"""
    # Converter para escala de cinza
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Aplicar filtro bilateral para reduzir ruído e preservar bordas
    bilateral = cv2.bilateralFilter(gray, 11, 17, 17)
    
    # Detectar bordas
    edged = cv2.Canny(bilateral, 30, 200)
    
    # Encontrar contornos
    contours, _ = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]
    
    # Procurar por contornos retangulares (possíveis placas)
    plate_contour = None
    for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.02 * perimeter, True)
        
        # Se o contorno tem 4 pontos, pode ser uma placa
        if len(approx) == 4:
            plate_contour = approx
            break
    
    if plate_contour is not None:
        # Criar máscara para a região da placa
        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [plate_contour], 0, 255, -1)
        
        # Aplicar a máscara para obter apenas a região da placa
        plate_img = cv2.bitwise_and(gray, gray, mask=mask)
        
        # Aplicar threshold para binarizar a imagem
        _, thresh = cv2.threshold(plate_img, 150, 255, cv2.THRESH_BINARY)
        
        return thresh
    
    # Se não encontrou contorno retangular, retorna a imagem em escala de cinza com threshold
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    return thresh

def extract_plate_from_image(image_data):
    """Extrai o número da placa de uma imagem"""
    # Converter dados da imagem para formato OpenCV
    nparr = np.frombuffer(image_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # Pré-processar a imagem
    processed_img = preprocess_image_for_plate_recognition(img)
    
    # Configurar Tesseract
    custom_config = configure_tesseract()
    
    # Reconhecer texto
    text = pytesseract.image_to_string(processed_img, config=custom_config)
    
    # Limpar o texto e extrair a placa
    text = text.strip()
    
    # Padrão de placa brasileira (formato antigo: ABC-1234 ou novo: ABC1D23)
    plate_pattern_old = r'[A-Z]{3}-?\d{4}'
    plate_pattern_new = r'[A-Z]{3}\d[A-Z]\d{2}'
    
    # Procurar por padrões de placa no texto
    old_match = re.search(plate_pattern_old, text)
    new_match = re.search(plate_pattern_new, text)
    
    if old_match:
        return old_match.group(0)
    elif new_match:
        return new_match.group(0)
    else:
        return None

# Funções para consulta à API FIPE
def get_fipe_brands():
    """Obtém a lista de marcas da API FIPE"""
    url = "https://parallelum.com.br/fipe/api/v1/carros/marcas"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    else:
        return []

def get_fipe_models(brand_id):
    """Obtém a lista de modelos para uma marca específica"""
    url = f"https://parallelum.com.br/fipe/api/v1/carros/marcas/{brand_id}/modelos"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {"modelos": []}

def get_fipe_years(brand_id, model_id):
    """Obtém a lista de anos para um modelo específico"""
    url = f"https://parallelum.com.br/fipe/api/v1/carros/marcas/{brand_id}/modelos/{model_id}/anos"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    else:
        return []

def get_fipe_vehicle_info(brand_id, model_id, year_id):
    """Obtém informações detalhadas de um veículo específico"""
    url = f"https://parallelum.com.br/fipe/api/v1/carros/marcas/{brand_id}/modelos/{model_id}/anos/{year_id}"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {}

def search_vehicle_by_name(vehicle_name):
    """Busca um veículo pelo nome (marca + modelo)"""
    # Obter todas as marcas
    brands = get_fipe_brands()
    
    # Normalizar o nome do veículo para busca
    vehicle_name = vehicle_name.upper()
    
    results = []
    
    # Para cada marca, buscar modelos que correspondam ao nome
    for brand in brands:
        brand_name = brand['nome'].upper()
        
        # Se o nome da marca está contido no nome do veículo
        if brand_name in vehicle_name:
            models = get_fipe_models(brand['codigo'])
            
            for model in models['modelos']:
                model_name = model['nome'].upper()
                
                # Se o nome do modelo está contido no nome do veículo
                if model_name in vehicle_name or any(word in vehicle_name for word in model_name.split()):
                    # Obter anos disponíveis
                    years = get_fipe_years(brand['codigo'], model['codigo'])
                    
                    # Para cada ano, obter informações detalhadas
                    for year in years:
                        vehicle_info = get_fipe_vehicle_info(brand['codigo'], model['codigo'], year['codigo'])
                        
                        if vehicle_info:
                            # Adicionar informações da marca e modelo
                            vehicle_info['marca_id'] = brand['codigo']
                            vehicle_info['modelo_id'] = model['codigo']
                            vehicle_info['ano_id'] = year['codigo']
                            
                            results.append(vehicle_info)
    
    return results

def get_vehicle_info_from_plate(plate):
    """Consulta informações do veículo a partir da placa usando a API FIPE"""
    # Remover caracteres não alfanuméricos
    plate_clean = re.sub(r'[^A-Z0-9]', '', plate)
    
    # Gerar dados simulados com base na placa
    first_letter = plate_clean[0] if plate_clean else 'A'
    
    # Mapear primeira letra para marcas comuns
    brands_map = {
        'A': 'TOYOTA', 'B': 'HONDA', 'C': 'VOLKSWAGEN', 'D': 'FIAT',
        'E': 'CHEVROLET', 'F': 'FORD', 'G': 'HYUNDAI', 'H': 'RENAULT',
        'I': 'NISSAN', 'J': 'MITSUBISHI', 'K': 'KIA', 'L': 'LAND ROVER',
        'M': 'MERCEDES-BENZ', 'N': 'BMW', 'O': 'AUDI', 'P': 'PEUGEOT',
        'Q': 'CITROEN', 'R': 'JEEP', 'S': 'SUBARU', 'T': 'SUZUKI',
        'U': 'VOLVO', 'V': 'CHERY', 'W': 'JAC', 'X': 'TROLLER',
        'Y': 'DODGE', 'Z': 'FERRARI'
    }
    
    # Mapear segunda letra para modelos
    models_map = {
        'A': 'COROLLA', 'B': 'CIVIC', 'C': 'GOL', 'D': 'PALIO',
        'E': 'ONIX', 'F': 'KA', 'G': 'HB20', 'H': 'SANDERO',
        'I': 'VERSA', 'J': 'LANCER', 'K': 'SPORTAGE', 'L': 'DISCOVERY',
        'M': 'C180', 'N': 'X1', 'O': 'A3', 'P': '208',
        'Q': 'C4', 'R': 'RENEGADE', 'S': 'FORESTER', 'T': 'JIMNY',
        'U': 'XC60', 'V': 'TIGGO', 'W': 'J3', 'X': 'T4',
        'Y': 'JOURNEY', 'Z': '458'
    }
    
    # Gerar ano baseado nos dígitos da placa
    year = 2000 + (int(plate_clean[-2:]) if len(plate_clean) >= 2 else 10)
    if year > 2025:  # Limitar ao ano atual
        year = 2000 + (int(plate_clean[-2:]) % 25)
    
    # Determinar tipo de combustível
    fuel_types = ['Flex', 'Gasolina', 'Diesel', 'Álcool', 'GNV', 'Híbrido', 'Elétrico']
    fuel = fuel_types[int(plate_clean[-1]) % len(fuel_types)] if plate_clean else fuel_types[0]
    
    # Determinar cor
    colors = ['Preto', 'Branco', 'Prata', 'Cinza', 'Vermelho', 'Azul', 'Verde', 'Amarelo', 'Marrom', 'Bege']
    color = colors[int(plate_clean[-3]) % len(colors)] if len(plate_clean) >= 3 else colors[0]
    
    # Gerar cilindrada baseada nos dígitos da placa
    engine_sizes = ['1.0', '1.4', '1.6', '1.8', '2.0', '2.5', '3.0', '3.5', '4.0', '5.0']
    engine = engine_sizes[int(plate_clean[-2]) % len(engine_sizes)] if len(plate_clean) >= 2 else engine_sizes[0]
    
    # Construir objeto de resposta
    brand = brands_map.get(first_letter, 'TOYOTA')
    model = models_map.get(plate_clean[1] if len(plate_clean) > 1 else 'A', 'COROLLA')
    
    # Buscar informações na API FIPE
    vehicle_name = f"{brand} {model}"
    fipe_results = search_vehicle_by_name(vehicle_name)
    
    # Se encontrou resultados na FIPE
    if fipe_results:
        # Pegar o primeiro resultado (mais relevante)
        fipe_info = fipe_results[0]
        
        # Extrair informações relevantes
        brand = fipe_info.get('Marca', brand)
        model = fipe_info.get('Modelo', model)
        year_model = fipe_info.get('AnoModelo', year)
        fuel = fipe_info.get('Combustivel', fuel)
        fipe_code = fipe_info.get('CodigoFipe', '')
        reference = fipe_info.get('MesReferencia', '')
        engine_info = re.search(r'(\d+\.\d+)', model)
        engine = engine_info.group(1) if engine_info else engine
        
        vehicle_info = {
            'plate': plate,
            'brand': brand,
            'model': model,
            'year': year_model,
            'color': color,
            'engine': engine,
            'fuel': fuel,
            'fipe_code': fipe_code,
            'reference': reference,
            'source': 'FIPE API'
        }
    else:
        # Se não encontrou na FIPE, usar dados simulados
        vehicle_info = {
            'plate': plate,
            'brand': brand,
            'model': model,
            'year': year,
            'color': color,
            'engine': engine,
            'fuel': fuel,
            'source': 'Simulação'
        }
    
    return vehicle_info

@fipe_api_bp.route('/plate/recognize', methods=['POST'])
def recognize_plate():
    """Reconhece a placa a partir de uma imagem"""
    if 'image' not in request.files:
        return jsonify({'error': 'Nenhuma imagem enviada'}), 400
    
    image_file = request.files['image']
    
    if image_file.filename == '':
        return jsonify({'error': 'Nome de arquivo vazio'}), 400
    
    # Ler dados da imagem
    image_data = image_file.read()
    
    # Extrair placa da imagem
    plate = extract_plate_from_image(image_data)
    
    if not plate:
        return jsonify({'error': 'Não foi possível reconhecer a placa na imagem'}), 400
    
    # Consultar informações do veículo
    vehicle_info = get_vehicle_info_from_plate(plate)
    
    return jsonify({
        'success': True,
        'plate': plate,
        'vehicle': vehicle_info
    })

@fipe_api_bp.route('/plate/info', methods=['GET'])
def get_plate_info():
    """Retorna informações do veículo a partir da placa"""
    plate = request.args.get('plate')
    
    if not plate:
        return jsonify({'error': 'Placa não especificada'}), 400
    
    # Validar formato da placa
    plate_pattern_old = r'^[A-Z]{3}-?\d{4}$'
    plate_pattern_new = r'^[A-Z]{3}\d[A-Z]\d{2}$'
    
    if not (re.match(plate_pattern_old, plate) or re.match(plate_pattern_new, plate)):
        return jsonify({'error': 'Formato de placa inválido'}), 400
    
    # Consultar informações do veículo
    vehicle_info = get_vehicle_info_from_plate(plate)
    
    return jsonify({
        'success': True,
        'vehicle': vehicle_info
    })

@fipe_api_bp.route('/brands', methods=['GET'])
def get_brands():
    """Retorna a lista de marcas da tabela FIPE"""
    brands = get_fipe_brands()
    
    return jsonify({
        'success': True,
        'brands': brands
    })

@fipe_api_bp.route('/models', methods=['GET'])
def get_models():
    """Retorna a lista de modelos para uma marca específica"""
    brand_id = request.args.get('brand_id')
    
    if not brand_id:
        return jsonify({'error': 'ID da marca não especificado'}), 400
    
    models = get_fipe_models(brand_id)
    
    return jsonify({
        'success': True,
        'models': models
    })

@fipe_api_bp.route('/years', methods=['GET'])
def get_years():
    """Retorna a lista de anos para um modelo específico"""
    brand_id = request.args.get('brand_id')
    model_id = request.args.get('model_id')
    
    if not brand_id or not model_id:
        return jsonify({'error': 'ID da marca ou modelo não especificado'}), 400
    
    years = get_fipe_years(brand_id, model_id)
    
    return jsonify({
        'success': True,
        'years': years
    })

@fipe_api_bp.route('/vehicle', methods=['GET'])
def get_vehicle():
    """Retorna informações detalhadas de um veículo específico"""
    brand_id = request.args.get('brand_id')
    model_id = request.args.get('model_id')
    year_id = request.args.get('year_id')
    
    if not brand_id or not model_id or not year_id:
        return jsonify({'error': 'Parâmetros incompletos'}), 400
    
    vehicle_info = get_fipe_vehicle_info(brand_id, model_id, year_id)
    
    return jsonify({
        'success': True,
        'vehicle': vehicle_info
    })

@fipe_api_bp.route('/search', methods=['GET'])
def search_vehicle():
    """Busca um veículo pelo nome"""
    name = request.args.get('name')
    
    if not name:
        return jsonify({'error': 'Nome do veículo não especificado'}), 400
    
    results = search_vehicle_by_name(name)
    
    return jsonify({
        'success': True,
        'results': results
    })
