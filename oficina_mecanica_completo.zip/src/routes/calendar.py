import os
import sys
from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import random
import json

# Blueprint para calendário de agendamentos
calendar_bp = Blueprint('calendar', __name__)

# Simulação de dados para demonstração
def generate_demo_appointments():
    # Dados de exemplo para demonstração
    current_date = datetime.now()
    start_date = current_date - timedelta(days=current_date.weekday())
    
    # Horários disponíveis
    time_slots = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00']
    
    # Tipos de serviço
    service_types = [
        'Troca de óleo',
        'Revisão geral',
        'Troca de pastilhas de freio',
        'Alinhamento e balanceamento',
        'Troca de amortecedores',
        'Reparo no sistema elétrico',
        'Diagnóstico de motor'
    ]
    
    # Clientes
    clients = [
        'AIRTON DA SILVA SOARES',
        'MARIA OLIVEIRA',
        'JOÃO SILVA',
        'CARLOS SANTOS',
        'ANA PEREIRA',
        'ROBERTO ALMEIDA',
        'PATRICIA FERREIRA'
    ]
    
    # Veículos
    vehicles = [
        'TOYOTA COROLLA XEI (BDM-1708)',
        'HONDA CIVIC (ABC-1234)',
        'FIAT PALIO (IJK-5678)',
        'VOLKSWAGEN GOL (DEF-9012)',
        'CHEVROLET ONIX (GHI-3456)',
        'FORD KA (JKL-7890)',
        'HYUNDAI HB20 (MNO-1234)'
    ]
    
    # Funcionários
    employees = [
        'Carlos Silva',
        'Roberto Almeida',
        'Ana Pereira',
        'Marcelo Santos',
        'Juliana Oliveira'
    ]
    
    # Gerar agendamentos para 4 semanas (2 semanas passadas, atual e próxima)
    appointments = []
    appointment_id = 1
    
    for week_offset in range(-2, 2):
        week_start = start_date + timedelta(days=7 * week_offset)
        
        for day in range(7):  # 7 dias da semana
            current_day = week_start + timedelta(days=day)
            
            # Pular finais de semana
            if current_day.weekday() >= 5:  # 5 = Sábado, 6 = Domingo
                continue
            
            # Número de agendamentos para este dia (entre 3 e 8)
            num_appointments = random.randint(3, 8)
            
            # Escolher horários aleatórios para este dia
            day_time_slots = random.sample(time_slots, num_appointments)
            
            for time_slot in day_time_slots:
                # Duração do serviço (entre 30 min e 3 horas, em incrementos de 30 min)
                duration_minutes = random.choice([30, 60, 90, 120, 150, 180])
                
                # Calcular horário de término
                start_time = datetime.strptime(time_slot, '%H:%M')
                end_time = start_time + timedelta(minutes=duration_minutes)
                end_time_str = end_time.strftime('%H:%M')
                
                # Dados do agendamento
                client = random.choice(clients)
                vehicle = random.choice(vehicles)
                service = random.choice(service_types)
                employee = random.choice(employees)
                
                # Status do agendamento
                if current_day < current_date.replace(hour=0, minute=0, second=0, microsecond=0):
                    status = 'concluído'
                elif current_day == current_date.replace(hour=0, minute=0, second=0, microsecond=0):
                    if start_time.hour < current_date.hour or (start_time.hour == current_date.hour and start_time.minute < current_date.minute):
                        status = random.choice(['concluído', 'cancelado'])
                    else:
                        status = 'agendado'
                else:
                    status = 'agendado'
                
                # Criar agendamento
                appointment = {
                    'id': appointment_id,
                    'title': f'{service} - {client}',
                    'start': f'{current_day.strftime("%Y-%m-%d")}T{time_slot}:00',
                    'end': f'{current_day.strftime("%Y-%m-%d")}T{end_time_str}:00',
                    'client': client,
                    'vehicle': vehicle,
                    'service': service,
                    'employee': employee,
                    'status': status,
                    'notes': f'Agendamento para {service} no veículo {vehicle}.',
                    'color': get_status_color(status)
                }
                
                appointments.append(appointment)
                appointment_id += 1
    
    return appointments

def get_status_color(status):
    """Retorna a cor correspondente ao status do agendamento"""
    colors = {
        'agendado': '#4caf50',  # Verde
        'concluído': '#2196f3',  # Azul
        'cancelado': '#f44336'   # Vermelho
    }
    return colors.get(status, '#9e9e9e')  # Cinza como padrão

@calendar_bp.route('/appointments', methods=['GET'])
def get_appointments():
    """Retorna todos os agendamentos"""
    # Parâmetros de filtro
    start_date = request.args.get('start')
    end_date = request.args.get('end')
    
    # Em uma implementação real, esses dados viriam do banco de dados
    # Para demonstração, estamos gerando dados aleatórios
    appointments = generate_demo_appointments()
    
    # Aplicar filtros de data
    if start_date and end_date:
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        filtered_appointments = []
        for appointment in appointments:
            appointment_start = datetime.fromisoformat(appointment['start'].replace('Z', '+00:00'))
            if start <= appointment_start <= end:
                filtered_appointments.append(appointment)
        
        appointments = filtered_appointments
    
    return jsonify(appointments)

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['GET'])
def get_appointment(appointment_id):
    """Retorna um agendamento específico"""
    appointments = generate_demo_appointments()
    
    # Buscar agendamento pelo ID
    appointment = next((a for a in appointments if a['id'] == appointment_id), None)
    
    if appointment:
        return jsonify(appointment)
    else:
        return jsonify({'error': 'Agendamento não encontrado'}), 404

@calendar_bp.route('/appointments', methods=['POST'])
def create_appointment():
    """Cria um novo agendamento"""
    # Em uma implementação real, isso salvaria no banco de dados
    # Para demonstração, apenas retornamos uma resposta de sucesso
    
    data = request.get_json()
    
    # Validar dados mínimos
    required_fields = ['title', 'start', 'end', 'client', 'vehicle', 'service', 'employee']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Campo obrigatório ausente: {field}'}), 400
    
    # Simular criação com ID
    new_appointment = data.copy()
    new_appointment['id'] = random.randint(1000, 9999)
    new_appointment['status'] = 'agendado'
    new_appointment['color'] = get_status_color('agendado')
    
    return jsonify({
        'success': True,
        'message': 'Agendamento criado com sucesso',
        'appointment': new_appointment
    }), 201

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['PUT'])
def update_appointment(appointment_id):
    """Atualiza um agendamento existente"""
    # Em uma implementação real, isso atualizaria o banco de dados
    # Para demonstração, apenas retornamos uma resposta de sucesso
    
    data = request.get_json()
    
    return jsonify({
        'success': True,
        'message': f'Agendamento {appointment_id} atualizado com sucesso',
        'appointment': {**data, 'id': appointment_id}
    })

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['DELETE'])
def delete_appointment(appointment_id):
    """Exclui um agendamento"""
    # Em uma implementação real, isso excluiria do banco de dados
    # Para demonstração, apenas retornamos uma resposta de sucesso
    
    return jsonify({
        'success': True,
        'message': f'Agendamento {appointment_id} excluído com sucesso'
    })

@calendar_bp.route('/availability', methods=['GET'])
def get_availability():
    """Retorna os horários disponíveis para agendamento"""
    # Parâmetros
    date = request.args.get('date')
    
    if not date:
        return jsonify({'error': 'Data não especificada'}), 400
    
    # Horários disponíveis padrão
    time_slots = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00']
    
    # Em uma implementação real, verificaríamos os agendamentos existentes
    # Para demonstração, removemos alguns horários aleatoriamente
    appointments = generate_demo_appointments()
    
    # Filtrar agendamentos para a data especificada
    date_appointments = [a for a in appointments if a['start'].startswith(date)]
    
    # Remover horários já agendados
    booked_slots = [a['start'].split('T')[1][:5] for a in date_appointments]
    available_slots = [slot for slot in time_slots if slot not in booked_slots]
    
    return jsonify({
        'date': date,
        'available_slots': available_slots
    })

@calendar_bp.route('/employees/availability', methods=['GET'])
def get_employee_availability():
    """Retorna a disponibilidade dos funcionários"""
    # Parâmetros
    date = request.args.get('date')
    
    if not date:
        return jsonify({'error': 'Data não especificada'}), 400
    
    # Funcionários
    employees = [
        'Carlos Silva',
        'Roberto Almeida',
        'Ana Pereira',
        'Marcelo Santos',
        'Juliana Oliveira'
    ]
    
    # Horários disponíveis padrão
    time_slots = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00']
    
    # Em uma implementação real, verificaríamos os agendamentos existentes
    # Para demonstração, geramos disponibilidade aleatória
    availability = {}
    
    for employee in employees:
        # Simular alguns horários ocupados
        occupied_slots = random.sample(time_slots, random.randint(2, 5))
        available_slots = [slot for slot in time_slots if slot not in occupied_slots]
        
        availability[employee] = {
            'name': employee,
            'available_slots': available_slots
        }
    
    return jsonify({
        'date': date,
        'employees': list(availability.values())
    })
