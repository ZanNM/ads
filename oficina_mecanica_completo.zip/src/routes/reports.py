import os
import sys
from flask import Blueprint, request, jsonify, render_template
from datetime import datetime, timedelta
import calendar
import json
import random

# Simulação de dados para demonstração
def generate_demo_data():
    # Dados de exemplo para demonstração
    current_year = datetime.now().year
    current_month = datetime.now().month
    
    # Gerar dados para os últimos 12 meses
    monthly_data = []
    for i in range(12):
        month = current_month - i
        year = current_year
        if month <= 0:
            month += 12
            year -= 1
        
        # Gerar valores aleatórios para demonstração
        ordens_concluidas = random.randint(30, 60)
        faturamento = ordens_concluidas * random.randint(300, 800)
        ticket_medio = faturamento / ordens_concluidas if ordens_concluidas > 0 else 0
        
        monthly_data.append({
            'mes': month,
            'ano': year,
            'nome_mes': calendar.month_name[month],
            'ordens_concluidas': ordens_concluidas,
            'faturamento': faturamento,
            'ticket_medio': ticket_medio
        })
    
    # Gerar dados para os tipos de serviço mais comuns
    servicos = [
        'Troca de óleo',
        'Revisão geral',
        'Troca de pastilhas de freio',
        'Alinhamento e balanceamento',
        'Troca de amortecedores',
        'Reparo no sistema elétrico',
        'Troca de correia dentada',
        'Diagnóstico de motor'
    ]
    
    servicos_data = []
    total_servicos = 0
    for servico in servicos:
        quantidade = random.randint(10, 50)
        total_servicos += quantidade
        servicos_data.append({
            'servico': servico,
            'quantidade': quantidade
        })
    
    # Calcular percentuais
    for item in servicos_data:
        item['percentual'] = (item['quantidade'] / total_servicos) * 100
    
    # Gerar dados para os clientes mais frequentes
    clientes = [
        'AIRTON DA SILVA SOARES',
        'MARIA OLIVEIRA',
        'JOÃO SILVA',
        'CARLOS SANTOS',
        'ANA PEREIRA',
        'ROBERTO ALMEIDA',
        'PATRICIA FERREIRA',
        'LUCAS MARTINS',
        'FERNANDA COSTA',
        'MARCELO RODRIGUES'
    ]
    
    clientes_data = []
    for cliente in clientes:
        visitas = random.randint(1, 8)
        valor_total = visitas * random.randint(200, 1000)
        clientes_data.append({
            'cliente': cliente,
            'visitas': visitas,
            'valor_total': valor_total,
            'ticket_medio': valor_total / visitas if visitas > 0 else 0
        })
    
    # Ordenar por visitas (decrescente)
    clientes_data.sort(key=lambda x: x['visitas'], reverse=True)
    
    # Gerar dados para veículos mais atendidos
    marcas = [
        'TOYOTA',
        'HONDA',
        'VOLKSWAGEN',
        'FIAT',
        'CHEVROLET',
        'FORD',
        'HYUNDAI',
        'RENAULT',
        'NISSAN',
        'MITSUBISHI'
    ]
    
    marcas_data = []
    total_atendimentos = 0
    for marca in marcas:
        atendimentos = random.randint(5, 40)
        total_atendimentos += atendimentos
        marcas_data.append({
            'marca': marca,
            'atendimentos': atendimentos
        })
    
    # Calcular percentuais
    for item in marcas_data:
        item['percentual'] = (item['atendimentos'] / total_atendimentos) * 100
    
    # Ordenar por atendimentos (decrescente)
    marcas_data.sort(key=lambda x: x['atendimentos'], reverse=True)
    
    return {
        'monthly_data': monthly_data,
        'servicos_data': servicos_data,
        'clientes_data': clientes_data,
        'marcas_data': marcas_data
    }

# Blueprint para relatórios
reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/dashboard', methods=['GET'])
def dashboard():
    """Retorna dados para o dashboard principal"""
    # Em uma implementação real, esses dados viriam do banco de dados
    # Para demonstração, estamos gerando dados aleatórios
    
    # Estatísticas gerais
    stats = {
        'ordens_abertas': random.randint(5, 15),
        'ordens_concluidas_mes': random.randint(30, 60),
        'faturamento_mes': random.randint(15000, 35000),
        'clientes_ativos': random.randint(100, 200)
    }
    
    # Ordens de serviço recentes
    ordens_recentes = []
    for i in range(1, 6):
        status_options = ['Pendente', 'Em andamento', 'Concluída']
        status_weights = [0.2, 0.3, 0.5]  # Mais chances de estar concluída
        status = random.choices(status_options, weights=status_weights)[0]
        
        # Data aleatória nos últimos 30 dias
        dias_atras = random.randint(0, 30)
        data = (datetime.now() - timedelta(days=dias_atras)).strftime('%d/%m/%Y')
        
        ordens_recentes.append({
            'numero': 2900 + i,
            'data': data,
            'cliente': f'Cliente {i}',
            'veiculo': f'Veículo {i}',
            'servico': f'Serviço {i}',
            'valor': random.randint(200, 1000),
            'status': status
        })
    
    # Ordenar por data (mais recente primeiro)
    ordens_recentes.sort(key=lambda x: datetime.strptime(x['data'], '%d/%m/%Y'), reverse=True)
    
    return jsonify({
        'stats': stats,
        'ordens_recentes': ordens_recentes
    })

@reports_bp.route('/faturamento', methods=['GET'])
def faturamento():
    """Retorna dados de faturamento para relatórios"""
    periodo = request.args.get('periodo', 'mensal')
    
    demo_data = generate_demo_data()
    
    if periodo == 'mensal':
        # Dados mensais dos últimos 12 meses
        return jsonify({
            'periodo': 'mensal',
            'dados': demo_data['monthly_data']
        })
    elif periodo == 'anual':
        # Agrupar dados por ano
        anos = {}
        for item in demo_data['monthly_data']:
            ano = item['ano']
            if ano not in anos:
                anos[ano] = {
                    'ano': ano,
                    'ordens_concluidas': 0,
                    'faturamento': 0
                }
            anos[ano]['ordens_concluidas'] += item['ordens_concluidas']
            anos[ano]['faturamento'] += item['faturamento']
        
        # Calcular ticket médio
        for ano in anos:
            anos[ano]['ticket_medio'] = anos[ano]['faturamento'] / anos[ano]['ordens_concluidas'] if anos[ano]['ordens_concluidas'] > 0 else 0
        
        return jsonify({
            'periodo': 'anual',
            'dados': list(anos.values())
        })
    else:
        return jsonify({'error': 'Período inválido'}), 400

@reports_bp.route('/servicos', methods=['GET'])
def servicos():
    """Retorna dados sobre os serviços mais realizados"""
    demo_data = generate_demo_data()
    
    return jsonify({
        'servicos': demo_data['servicos_data']
    })

@reports_bp.route('/clientes', methods=['GET'])
def clientes():
    """Retorna dados sobre os clientes mais frequentes"""
    demo_data = generate_demo_data()
    
    return jsonify({
        'clientes': demo_data['clientes_data']
    })

@reports_bp.route('/veiculos', methods=['GET'])
def veiculos():
    """Retorna dados sobre os veículos mais atendidos"""
    demo_data = generate_demo_data()
    
    return jsonify({
        'marcas': demo_data['marcas_data']
    })

@reports_bp.route('/desempenho', methods=['GET'])
def desempenho():
    """Retorna dados de desempenho dos funcionários"""
    # Dados de exemplo para demonstração
    funcionarios = [
        'Carlos Silva',
        'Roberto Almeida',
        'Ana Pereira',
        'Marcelo Santos',
        'Juliana Oliveira'
    ]
    
    funcionarios_data = []
    for funcionario in funcionarios:
        ordens_concluidas = random.randint(10, 30)
        tempo_medio = random.randint(2, 8)  # Horas
        avaliacao_media = round(random.uniform(3.5, 5.0), 1)
        
        funcionarios_data.append({
            'funcionario': funcionario,
            'ordens_concluidas': ordens_concluidas,
            'tempo_medio': tempo_medio,
            'avaliacao_media': avaliacao_media
        })
    
    # Ordenar por ordens concluídas (decrescente)
    funcionarios_data.sort(key=lambda x: x['ordens_concluidas'], reverse=True)
    
    return jsonify({
        'funcionarios': funcionarios_data
    })
