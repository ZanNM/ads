# Sistema de Gerenciamento de Ordens de Serviço - Oficina Mecânica

Este projeto é um sistema web desenvolvido com Flask para gerenciar ordens de serviço de uma oficina mecânica, com diferentes níveis de acesso para funcionários e administradores, além de processamento de PDFs com IA.

## Estrutura do Projeto

```
oficina_mecanica/
├── venv/                  # Ambiente virtual Python
├── src/                   # Código-fonte da aplicação
│   ├── models/            # Modelos de banco de dados
│   ├── routes/            # Rotas e endpoints da API
│   ├── static/            # Arquivos estáticos (HTML, CSS, JS)
│   └── main.py            # Ponto de entrada da aplicação
└── requirements.txt       # Dependências do projeto
```

## Funcionalidades Planejadas

1. **Autenticação e Controle de Acesso**
   - Login para funcionários e administradores
   - Diferentes níveis de permissão

2. **Gerenciamento de Ordens de Serviço**
   - Cadastro de clientes e veículos
   - Criação e edição de ordens de serviço
   - Visualização de tarefas por veículo

3. **Processamento de PDF com IA**
   - Upload de PDFs de ordens de serviço
   - Extração automática de informações
   - Conversão para formato estruturado

4. **Restrição de Visualização**
   - Funcionários: sem acesso a informações de preços
   - Administradores: acesso completo a todas as informações

## Próximos Passos

1. Implementar modelos de banco de dados
2. Configurar sistema de autenticação
3. Desenvolver interface de usuário
4. Integrar processamento de PDF com IA
5. Implementar restrições de visualização
6. Testar e implantar o sistema

## Como Executar o Projeto

1. Ative o ambiente virtual:
   ```
   cd oficina_mecanica
   source venv/bin/activate
   ```

2. Execute a aplicação:
   ```
   python src/main.py
   ```

3. Acesse a aplicação em: http://localhost:5000
