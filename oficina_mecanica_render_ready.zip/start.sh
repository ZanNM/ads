#!/bin/bash
export PYTHONUNBUFFERED=1
python src/main.py
