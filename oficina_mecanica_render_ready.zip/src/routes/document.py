from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
import os
from src.utils.document_processor import allowed_file, process_document

document_bp = Blueprint('document', __name__)

@document_bp.route('/upload', methods=['POST'])
def upload_document():
    # Verificar se o arquivo foi enviado
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado'}), 400
    
    file = request.files['file']
    
    # Verificar se o nome do arquivo está vazio
    if file.filename == '':
        return jsonify({'error': 'Nome de arquivo vazio'}), 400
    
    # Verificar se o arquivo é permitido
    if file and allowed_file(file.filename):
        # Garantir que o nome do arquivo seja seguro
        filename = secure_filename(file.filename)
        
        # Criar diretório de uploads se não existir
        upload_folder = os.path.join(current_app.root_path, 'uploads')
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)
        
        # Salvar o arquivo
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)
        
        # Processar o documento
        result = process_document(file_path)
        
        return jsonify({
            'message': 'Arquivo processado com sucesso',
            'filename': filename,
            'resultado': result
        })
    
    return jsonify({'error': 'Tipo de arquivo não permitido'}), 400

@document_bp.route('/process/<filename>', methods=['GET'])
def process_existing_document(filename):
    # Verificar se o arquivo existe
    upload_folder = os.path.join(current_app.root_path, 'uploads')
    file_path = os.path.join(upload_folder, filename)
    
    if not os.path.exists(file_path):
        return jsonify({'error': 'Arquivo não encontrado'}), 404
    
    # Verificar se o arquivo é permitido
    if allowed_file(filename):
        # Processar o documento
        result = process_document(file_path)
        
        return jsonify({
            'message': 'Arquivo processado com sucesso',
            'filename': filename,
            'resultado': result
        })
    
    return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
