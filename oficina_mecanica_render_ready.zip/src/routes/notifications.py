import os
import sys
from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import random
import json

# Blueprint para notificações
notifications_bp = Blueprint('notifications', __name__)

# Simulação de dados para demonstração
def generate_demo_notifications():
    # Tipos de notificações
    notification_types = [
        {
            'type': 'ordem_pendente',
            'title': 'Ordem de Serviço Pendente',
            'message': 'A Ordem de Serviço #{} está pendente há {} dias.',
            'priority': 'high'
        },
        {
            'type': 'agendamento',
            'title': 'Agendamento Próximo',
            'message': 'Agendamento para {} marcado para amanhã às {}.',
            'priority': 'medium'
        },
        {
            'type': 'ordem_concluida',
            'title': 'Ordem de Serviço Concluída',
            'message': 'A Ordem de Serviço #{} foi concluída e está pronta para entrega.',
            'priority': 'low'
        },
        {
            'type': 'feedback',
            'title': 'Feedback Pendente',
            'message': 'Solicite feedback do cliente {} sobre o serviço realizado.',
            'priority': 'medium'
        }
    ]
    
    # Gerar notificações aleatórias
    notifications = []
    
    # Ordens pendentes
    for i in range(1, 4):
        ordem_id = 2900 + i
        dias_pendente = random.randint(1, 5)
        notification = notification_types[0].copy()
        notification['id'] = i
        notification['message'] = notification['message'].format(ordem_id, dias_pendente)
        notification['created_at'] = (datetime.now() - timedelta(hours=random.randint(1, 24))).isoformat()
        notification['read'] = False
        notifications.append(notification)
    
    # Agendamentos próximos
    clientes = ['AIRTON DA SILVA SOARES', 'MARIA OLIVEIRA', 'JOÃO SILVA']
    horarios = ['09:00', '10:30', '14:15']
    
    for i in range(3, 6):
        cliente = random.choice(clientes)
        horario = random.choice(horarios)
        notification = notification_types[1].copy()
        notification['id'] = i
        notification['message'] = notification['message'].format(cliente, horario)
        notification['created_at'] = (datetime.now() - timedelta(hours=random.randint(1, 12))).isoformat()
        notification['read'] = random.choice([True, False])
        notifications.append(notification)
    
    # Ordens concluídas
    for i in range(6, 9):
        ordem_id = 2890 + i
        notification = notification_types[2].copy()
        notification['id'] = i
        notification['message'] = notification['message'].format(ordem_id)
        notification['created_at'] = (datetime.now() - timedelta(hours=random.randint(1, 36))).isoformat()
        notification['read'] = random.choice([True, False])
        notifications.append(notification)
    
    # Feedback pendente
    for i in range(9, 12):
        cliente = random.choice(clientes)
        notification = notification_types[3].copy()
        notification['id'] = i
        notification['message'] = notification['message'].format(cliente)
        notification['created_at'] = (datetime.now() - timedelta(hours=random.randint(1, 48))).isoformat()
        notification['read'] = random.choice([True, False])
        notifications.append(notification)
    
    # Ordenar por data de criação (mais recente primeiro)
    notifications.sort(key=lambda x: x['created_at'], reverse=True)
    
    return notifications

@notifications_bp.route('/', methods=['GET'])
def get_notifications():
    """Retorna todas as notificações"""
    # Parâmetros de filtro
    unread_only = request.args.get('unread', 'false').lower() == 'true'
    
    # Em uma implementação real, esses dados viriam do banco de dados
    # Para demonstração, estamos gerando dados aleatórios
    notifications = generate_demo_notifications()
    
    # Aplicar filtro de não lidas
    if unread_only:
        notifications = [n for n in notifications if not n['read']]
    
    return jsonify({
        'notifications': notifications,
        'count': len(notifications),
        'unread_count': len([n for n in notifications if not n['read']])
    })

@notifications_bp.route('/<int:notification_id>', methods=['GET'])
def get_notification(notification_id):
    """Retorna uma notificação específica"""
    notifications = generate_demo_notifications()
    
    # Buscar notificação pelo ID
    notification = next((n for n in notifications if n['id'] == notification_id), None)
    
    if notification:
        return jsonify(notification)
    else:
        return jsonify({'error': 'Notificação não encontrada'}), 404

@notifications_bp.route('/<int:notification_id>/read', methods=['POST'])
def mark_as_read(notification_id):
    """Marca uma notificação como lida"""
    # Em uma implementação real, isso atualizaria o banco de dados
    # Para demonstração, apenas retornamos uma resposta de sucesso
    
    return jsonify({
        'success': True,
        'message': f'Notificação {notification_id} marcada como lida'
    })

@notifications_bp.route('/read-all', methods=['POST'])
def mark_all_as_read():
    """Marca todas as notificações como lidas"""
    # Em uma implementação real, isso atualizaria o banco de dados
    # Para demonstração, apenas retornamos uma resposta de sucesso
    
    return jsonify({
        'success': True,
        'message': 'Todas as notificações marcadas como lidas'
    })

@notifications_bp.route('/count', methods=['GET'])
def get_notification_count():
    """Retorna apenas a contagem de notificações não lidas"""
    notifications = generate_demo_notifications()
    unread_count = len([n for n in notifications if not n['read']])
    
    return jsonify({
        'unread_count': unread_count
    })
