// Arquivo para controle de permissões de edição de ordens de serviço
// Este arquivo deve ser incluído em todas as páginas que manipulam ordens de serviço

// Função para verificar se o usuário atual tem permissão para editar ordens
function canEditOrders() {
    // Obter o papel do usuário da sessão
    const userRole = getUserRole();
    
    // Apenas administradores podem editar ordens de serviço
    return userRole === 'admin';
}

// Função para obter o papel do usuário atual
function getUserRole() {
    // Em uma implementação real, isso viria da sessão ou token JWT
    // Para demonstração, vamos simular com base no usuário logado
    const currentUser = getCurrentUser();
    return currentUser ? currentUser.role : null;
}

// Função para obter o usuário atual
function getCurrentUser() {
    // Em uma implementação real, isso viria da sessão ou localStorage
    // Para demonstração, vamos simular um usuário logado
    return JSON.parse(localStorage.getItem('currentUser')) || null;
}

// Função para configurar a interface com base nas permissões
function setupOrderInterface() {
    const canEdit = canEditOrders();
    
    // Ocultar ou desabilitar elementos de edição para funcionários comuns
    const editButtons = document.querySelectorAll('.edit-order-btn');
    const deleteButtons = document.querySelectorAll('.delete-order-btn');
    const editForms = document.querySelectorAll('.edit-order-form');
    
    // Configurar botões de edição
    editButtons.forEach(button => {
        if (!canEdit) {
            button.style.display = 'none';
        }
    });
    
    // Configurar botões de exclusão
    deleteButtons.forEach(button => {
        if (!canEdit) {
            button.style.display = 'none';
        }
    });
    
    // Configurar formulários de edição
    editForms.forEach(form => {
        if (!canEdit) {
            // Desabilitar todos os campos do formulário
            const inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.disabled = true;
            });
            
            // Adicionar mensagem informativa
            const infoMessage = document.createElement('div');
            infoMessage.className = 'info-message';
            infoMessage.textContent = 'Apenas administradores podem editar ordens de serviço.';
            form.prepend(infoMessage);
        }
    });
    
    // Configurar mensagem para funcionários
    const permissionMessage = document.getElementById('permission-message');
    if (permissionMessage) {
        if (!canEdit) {
            permissionMessage.textContent = 'Você tem permissão apenas para visualizar ordens de serviço. Para editar, contate um administrador.';
            permissionMessage.style.display = 'block';
        } else {
            permissionMessage.style.display = 'none';
        }
    }
}

// Executar a configuração da interface quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', setupOrderInterface);

// Exportar funções para uso em outros arquivos
window.orderPermissions = {
    canEditOrders,
    getUserRole,
    setupOrderInterface
};
